// ID Spreadsheet Google Anda (Bisa dikosongkan terlebih dahulu untuk mode Demo)
const SHEET_ID = 'MASUKKAN_ID_SPREADSHEET_ANDA_DI_SINI'; 

function doGet(e) {
  // Menggunakan createTemplateFromFile agar sintaks <?!= include() ?> dirender sebagai visual HTML/JS murni
  const template = HtmlService.createTemplateFromFile('Index');
  return template.evaluate()
    .setTitle('Loop Apps 3D')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// Fungsi penyambung komponen HTML dan JavaScript
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// Fungsi menyimpan pesan/log ke Google Sheets tanpa membuat aplikasi crashing
function saveMessage(username, message) {
  try {
    if (!SHEET_ID || SHEET_ID.includes('MASUKKAN_ID')) {
      return { success: true, message: "Koneksi Berhasil (Mode Demo)" };
    }
    const sheet = SpreadsheetApp.openById(SHEET_ID).getActiveSheet();
    sheet.appendRow([new Date(), username, message]);
    return { success: true, message: "Data tersimpan di Sheet!" };
  } catch (error) {
    return { success: false, error: error.toString() };
  }
}